# -*- coding: utf-8 -*-

#arquivo = raw_input("arquivo de entrada: ") 
arquivo = 'pp-oferta-116'
out_disciplinas = open('carrega_disciplinas.sql', 'w')
out_professores = open('carrega_professores.sql', 'w')
out_ofertas = open('carrega_ofertas.sql', 'w')

disciplinas = {}
professores = {}


with open(arquivo) as f:
    for line in f:
        line = line.rstrip()

        colunas = line.split(',')
        
        cod = colunas[0]
        
        if(not(disciplinas.has_key(cod))):
            disciplinas[cod] = colunas[1]
        
        for i in range(4, len(colunas)):
            if(not(professores.has_key(colunas[i]))):
               professores[colunas[i]] = len(professores) + 1

    for chave in disciplinas:        
		out_disciplinas.write("INSERT INTO DISCIPLINA VALUES(NEXT VALUE FOR SEQ_DISCIPLINA " + ", " + chave + " , '" + disciplinas[chave] + "'); COMMIT; \n");
		
    for chave in professores:
        out_professores.write("INSERT INTO PROFESSOR VALUES(NEXT VALUE FOR SEQ_PROFESSOR " + ", " + str(professores[chave]) + ", '" + chave + "', '12345'); COMMIT;\n"); 

    f.close()
    
with open(arquivo) as f:
    for line in f:
        line = line.rstrip()

        colunas = line.split(',')
    
        for i in range(4, len(colunas)):
            out_ofertas.write("INSERT INTO OFERTA VALUES(NEXT VALUE FOR SEQ_OFERTA " + ", " + colunas[0] + ",'" + colunas[2] + "'," + colunas[3] + "," + str(professores[colunas[i]]) + "); COMMIT;\n"); 
