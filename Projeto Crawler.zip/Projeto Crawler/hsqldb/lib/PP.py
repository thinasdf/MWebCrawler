import codecs 

#arquivo = raw_input("arquivo de entrada: ") 
arquivo = 'oferta-116'
out = open('pp-' + arquivo, 'w')

with open(arquivo) as f:
    for line in f:
        line = line.replace("[", "")
        line = line.replace("]", "")
        line = line.replace("'", "")
        out.write(line)

out.close()
 
