#  -*- coding: utf-8 -*-
#       @file: MatriculaWeb.py
#     @author: Guilherme N. Ramos (gnramos@unb.br)
#       @date: 2016/04/19
#
# Web-crawler para buscar informações da lista de oferta de cursos da UnB.
#
# O programa busca as informações com base em expressões regulares que,
# assume-se, representam a estrutura de uma página do Matrícula Web. Caso esta
# estrutura seja alterada, as expressões aqui precisam ser atualizadas de
# acordo.


import requests
import re


class Oferta:
    """Lida com a Lista de Oferta."""

    def __url(self, curso, pagina, cod):
        mweb = 'https://matriculaweb.unb.br/matriculaweb/' + str(curso)
        link = str(pagina) + '.aspx?cod=' + str(cod)
        return mweb + '/' + link

    def departamento(self, dept=116, curso='graduacao'):
        """Acessa o Matrícula Web e retorna um dicionário com a lista de
        disciplinas ofertadas por um departamento.

        Argumentos:
        dept -- o código do Departamento que oferece as disciplinas
                (default 116).
        curso -- nível acadêmico das disciplinas buscadas: graduacao ou
                 posgraduacao.
                 (default graduacao).

        Lista completa dos Departamentos da UnB:
        matriculaweb.unb.br/matriculaweb/graduacao/oferta_dep.aspx?cod=1
        """
        REGEX = 'oferta_dados.aspx\?cod=(\d+).*?>(.*?)</a>'

        url_oferta = self.__url(curso, 'oferta_dis', dept)

        lof = {}
        try:
            html_page = requests.get(url_oferta)
            oferta = re.findall(REGEX, html_page.content)
            for codigo, disciplina in oferta:
                lof[codigo] = {}
                lof[codigo]['nome'] = disciplina
        except requests.exceptions.ConnectionError as erro:
            print('Erro processando a requisicao') 
            pass

        return lof

    def disciplina(self, codigo, curso='graduacao'):
        """Acessa o Matrícula Web e retorna um dicionário com a lista de turmas
        ofertadas para uma disciplina.

        Argumentos:
        codigo -- o código da disciplina.
        curso -- nível acadêmico das disciplinas buscadas: graduacao ou
                 posgraduacao (default graduacao).
        """
        REGEX = '<font size=4><b>(\w+)</b></font>' \
                '</div>        <font size=1 face=Verdana, Arial, Helvetica, ' \
                'sans-serif><br></font>      </td>     ' \
                '<td width=200 align=middle bgcolor=whitesmoke>         ' \
                '<table width=100%>           ' \
                '<tr class=padraomenor halign=center valign=middle>' \
                '<td>Total</td><td>Vagas</td>' \
                '<td><b>\d+</b></td></tr>           ' \
                '<tr class=padraomenor halign=center valign=middle><td></td>' \
                '<td>Ocupadas</td>' \
                '<td><b><font color=\w+>(\d+)</font></b></td>' \
                '.*?' \
                '<td valign=middle class=padraomenor bgcolor=whitesmoke>' \
                '<center>(.*?)<br></center>'

        url_oferta = self.__url(curso, 'oferta_dados', codigo)

        lof = {}
        try:
            html_page = requests.get(url_oferta)
            ocupadas = re.findall(REGEX, html_page.content)
            for turma, vagas, professores in ocupadas:
                vagas_ocupadas = int(vagas)
                if vagas_ocupadas > 0:
                    lof[turma] = {}
                    lof[turma]['alunos'] = vagas_ocupadas
                    lof[turma]['professores'] = professores.split('<br>')
        except requests.exceptions.ConnectionError as erro:
            pass
            # print 'Erro ao buscar %s para %s.\n%s' % (codigo, curso, erro)

        return lof

    def lista_de_espera(self, codigo, curso='graduacao'):
        """Acessa o Matrícula Web e retorna um dicionário com a lista de espera
        para as turmas da disciplina ofertada.

        Argumentos:
        codigo -- o código da disciplina
        curso -- nível acadêmico das disciplinas buscadas: graduacao ou
                 posgraduacao (default graduacao).
        """
        REGEX_TABELA = '<td><b>Turma</b></td>    ' \
                       '<td><b>Vagas<br>Solicitadas</b></td>  </tr>' \
                       '<tr CLASS=PadraoMenor bgcolor=#E7F3D6>  ' \
                       '.*?</tr><tr CLASS=PadraoBranco>'
        REGEX = '<td align=center >(\w+)</td>  ' \
                '<td align=center >(\d+)</td></tr>'

        url_oferta = self.__url(curso, 'faltavaga_rel', codigo)

        le = {}
        try:
            html_page = requests.get(url_oferta)
            tabelas = re.findall(REGEX_TABELA, html_page.content)
            for tabela in tabelas:
                for turma, vagas in re.findall(REGEX, tabela):
                    vagas_desejadas = int(vagas)
                    if vagas_desejadas > 0:
                        le[turma] = vagas_desejadas
        except requests.exceptions.ConnectionError as erro:
            print('Erro ao processar a requisicao')

        return le
