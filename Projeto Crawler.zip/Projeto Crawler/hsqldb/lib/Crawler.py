from MatriculaWeb import Oferta

import codecs

oferta = Oferta()

#dept = input("Informe o codigo do departamento: ")
dept = 116
disciplinas = oferta.departamento(dept)

f = codecs.open('oferta-' + str(dept), 'w',"utf-8")

for cod in disciplinas.iterkeys():
    turmas = oferta.disciplina(codigo = cod)

    for turma in turmas.iterkeys():
        res = str(cod) + "," + (disciplinas[cod]["nome"]).decode("utf-8") + "," + turma + "," + str(turmas[turma]["alunos"]) + "," + str(turmas[turma]["professores"]).decode("utf-8")

        f.write(res + '\n')
#    listaDeEspera = oferta.lista_de_espera(codigo = cod)
    
#    for turma in listaDeEspera.iterkeys():
#        res = str(cod)+ ',' + disciplinas[cod]["nome"] + ", " + turma + ", " + str(listaDeEspera[turma]) 
#        f.write(res + '\n')

f.close()
